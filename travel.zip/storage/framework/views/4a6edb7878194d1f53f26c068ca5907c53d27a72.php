<?php $__env->startSection('title','Details'); ?>
<?php $__env->startSection('content'); ?>


<!--// Sub Header //-->
<div class="kd-subheader">
<div class="container">
<div class="row">
<div class="col-md-12">

<div class="subheader-info">
<h1> <?php echo e($CountryName->name); ?> </h1>
</div>
</div>
</div>
</div>
</div>

<!--// Sub Header //-->





    <!--// Content //-->
    <div class="kd-content">

      <!--// Page Section //-->
      <section class="kd-pagesection" style=" padding: 0px 0px 10px 0px; ">
        <div class="container">
          <div class="row">

            <div class="col-md-12">
              <div class="kd-package-list">
                <div class="row">




			
			



<?php $__currentLoopData = $CountryTour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CountryTours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<article class="col-md-4">
<figure><a href="#"><img src="/images/<?php echo e($CountryTours->main_image); ?>" alt=""></a>
<figcaption>

<span class="package-price thbg-color">BDT 5500</span>

<div class="kd-bottomelement">
	<h5>
		<a href="/tour/<?php echo e($CountryTours->id); ?>">
		<?php echo e($CountryTours->title); ?>

		</a>
	</h5>	
<div class="days-counter" style="background-color: #087dc2;"><span>3</span> <br> days</div>
</div>

</figcaption>
</figure>
</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                
              </div>
            </div>

          </div>



                <div class="text-center">
                    <ul class="pagination"><li class="disabled"><span>&laquo;</span></li> <li class="active"><span>1</span></li><li><a href="bangladesh4658.html?page=2">2</a></li><li><a href="bangladesh9ba9.html?page=3">3</a></li><li><a href="bangladeshfdb0.html?page=4">4</a></li> <li><a href="bangladesh4658.html?page=2" rel="next">&raquo;</a></li></ul>
                </div>


    



        </div>
      </section>
      <!--// Page Section //-->

    </div>
    <!--// Content //-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>