<?php $__env->startSection('title','Edit Tour'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
        <div class="col-md-12">
        <?php if(count($errors) > 0): ?>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="alert alert-danger alert-dismissable">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			 <center><i class="fa fa-info-circle"></i>  <strong style="font-size:12px;"><?php echo e($error); ?></strong> </center>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?> 
        </div>
        </div>
	<div class="row">
	
			<div class="panel panel-primary" style="border:1px solid #FF0A00;"> 
        		<div class="panel-heading" style="background-color:#FF0A00; border:1px solid #FF0A00;font-size:16px;font-weight:bold">
					<b>Edit Travel</b>
				</div><!--panel-heading end-->
				<div class="panel-body">
					<?php echo Form::open(array('action' => ['CountryController@update',$country->id],'class'=>'form-horizontal','enctype'=>'multipart/form-data','method'=>'POST')); ?>

					
					<div class="form-group">
							<?php echo Form::label('name', 'Name',$attribute=['class'=>'col-md-2 control-label']);; ?>

						
						<div class="col-md-10">
							<?php echo Form::text('name', $value=$country->name,$attribute=['class'=>'form-control input-md','name'=>'name']);; ?>

						</div>
					</div>
					
					<div class="form-group">
						  <div class="col-md-12" align="right">

							<a href="/country/"><input  type="button" name="cancel" align="right" value="Cancel" class="btn btn-danger" /></a>
						  
						  <?php echo Form::submit('Update', $attribute=['class'=>'btn btn-success','name'=>'Submit']);; ?>

						  </div>
					  </div>
					  <?php echo method_field('PUT'); ?>

					<?php echo Form::close(); ?>

				</div><!--panel-body end-->
			</div><!--panel content end-->
		
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>