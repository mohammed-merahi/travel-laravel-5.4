<?php $__env->startSection('title','Tour List'); ?>
<?php $__env->startSection('content'); ?>
		<?php if(Session::has('message')): ?>
		<div class="row">
        <div class="col-md-12">	
		<div class="alert alert-info alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			 <center><i class="fa fa-info-circle"></i>  <strong style="font-size:16px;"><?php echo e(Session::get('message')); ?></strong> </center>
			</div>
			</div>
        </div>
		<?php endif; ?>
		<div class="row">
        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Title</th>
				<th>Detail</th>
				<th>Location</th>
				<th>Image</th>
				<th>Edit</th>
				<th>Delete</th>
                
                
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $travel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
			<tr>
                <td><?php echo e($travels->title); ?></td>
                <td><?php echo e($travels->detail); ?></td>
                <td><?php echo e($travels->location); ?></td>
				<td align="center" ><img class="img-responsive thumbnail" src="/images/<?php echo e($travels->main_image); ?>"  /></td>
                <?php if(!Auth::guest()): ?>
					<?php if(Auth::user()->id==$travels->owner_id): ?>
				<td align="center"><a href="/supertravel/<?php echo e($travels->id); ?>/edit"><button  class="btn btn-info">Edit</button></a></td>
				<td align="center" style="color:#000">
					<?php echo Form::open(['method'=>'DELETE','route'=>['supertravel.destroy',$travels->id]]); ?>

						<?php echo Form::submit('DELETE',$attribute=['class'=>'btn btn-danger']);; ?>

						<?php echo Form::close(); ?>

				  <?php else: ?>
					<td align="center"><span style="color:#CD1142;" class="glyphicon glyphicon-edit disabled"></span></td>
				<td align="center" style="color:#000">
				  <span style="color:#F00;" class="glyphicon glyphicon-trash disabled"></span></td>
				  <?php endif; ?>
				  <?php endif; ?>
				  </td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>