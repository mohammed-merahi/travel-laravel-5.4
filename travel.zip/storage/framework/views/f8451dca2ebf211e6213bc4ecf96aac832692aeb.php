<?php $__env->startSection('title','Show'); ?>
<?php $__env->startSection('content'); ?>


	<div class="row">
        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Title</th>
				<th>Detail</th>
				<th>Location</th>
				<th>Image</th>
				
                
                
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $supertravel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supertravels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
			<tr>
                <td><?php echo e($supertravels->title); ?></td>
                <td><?php echo e($supertravels->detail); ?></td>
                <td><?php echo e($supertravels->location); ?></td>
				<td align="center" ><img class="img-responsive thumbnail" src="/images/<?php echo e($supertravels->main_image); ?>"  /></td>
                
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>